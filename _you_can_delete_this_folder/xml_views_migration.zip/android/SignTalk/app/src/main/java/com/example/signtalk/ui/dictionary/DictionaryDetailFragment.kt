package com.example.signtalk.ui.dictionary

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.signtalk.SignTalkApp
import com.example.signtalk.databinding.FragmentDictionaryDetailBinding
import kotlinx.coroutines.launch

class DictionaryDetailFragment : Fragment() {

    private var _binding: FragmentDictionaryDetailBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentDictionaryDetailBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val appContainer = (requireActivity().application as SignTalkApp).container
        val entryId = arguments?.getLong("entryId") ?: 0L

        viewLifecycleOwner.lifecycleScope.launch {
            val entry = appContainer.dictionaryRepository.getEntry(entryId)
            if (entry == null) {
                binding.loadingText.text = "Sign not found."
                return@launch
            }
            (requireActivity() as? AppCompatActivity)?.supportActionBar?.title = entry.displayName

            binding.loadingText.visibility = View.GONE
            binding.contentGroup.visibility = View.VISIBLE
            binding.entryEmoji.text = entry.emoji
            binding.entryCategory.text = entry.category
            binding.entryDescription.text = entry.description

            if (entry.isUserAdded) {
                binding.deleteButton.visibility = View.VISIBLE
                binding.deleteButton.setOnClickListener {
                    viewLifecycleOwner.lifecycleScope.launch {
                        appContainer.dictionaryRepository.deleteEntry(entry.id)
                        findNavController().popBackStack()
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

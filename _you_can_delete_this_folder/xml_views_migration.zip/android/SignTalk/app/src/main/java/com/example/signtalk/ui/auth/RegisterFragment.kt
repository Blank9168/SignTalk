package com.example.signtalk.ui.auth

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navGraphViewModels
import com.example.signtalk.R
import com.example.signtalk.SignTalkApp
import com.example.signtalk.databinding.FragmentRegisterBinding
import kotlinx.coroutines.launch

class RegisterFragment : Fragment() {

    private var _binding: FragmentRegisterBinding? = null
    private val binding get() = _binding!!

    // Same graph-scoped AuthViewModel instance as LoginFragment.
    private val viewModel: AuthViewModel by navGraphViewModels(R.id.nav_graph) {
        viewModelFactory {
            initializer {
                val appContainer = (requireActivity().application as SignTalkApp).container
                AuthViewModel(appContainer.authRepository)
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentRegisterBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        for (field in listOf(binding.nameInput, binding.emailInput, binding.passwordInput, binding.confirmPasswordInput)) {
            field.doAfterTextChanged { viewModel.clearError() }
        }

        binding.registerButton.setOnClickListener {
            viewModel.register(
                binding.nameInput.text?.toString().orEmpty(),
                binding.emailInput.text?.toString().orEmpty(),
                binding.passwordInput.text?.toString().orEmpty(),
                binding.confirmPasswordInput.text?.toString().orEmpty()
            )
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { state ->
                    binding.registerButton.isEnabled = !state.isLoading
                    binding.registerProgress.visibility = if (state.isLoading) View.VISIBLE else View.GONE
                    binding.registerButton.text = if (state.isLoading) "" else "Create account"

                    if (state.errorMessage != null) {
                        binding.errorText.text = state.errorMessage
                        binding.errorText.visibility = View.VISIBLE
                    } else {
                        binding.errorText.visibility = View.GONE
                    }

                    if (state.isAuthenticated) {
                        findNavController().navigate(R.id.action_register_to_home)
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

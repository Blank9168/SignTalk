package com.example.signtalk.ui.auth

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.widget.doAfterTextChanged
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navGraphViewModels
import com.example.signtalk.R
import com.example.signtalk.SignTalkApp
import com.example.signtalk.databinding.FragmentLoginBinding
import kotlinx.coroutines.launch

class LoginFragment : Fragment() {

    private var _binding: FragmentLoginBinding? = null
    private val binding get() = _binding!!

    // Graph-scoped so Login and Register share one AuthViewModel instance,
    // the same way both screens shared it in the old Compose nav graph.
    private val viewModel: AuthViewModel by navGraphViewModels(R.id.nav_graph) {
        viewModelFactory {
            initializer {
                val appContainer = (requireActivity().application as SignTalkApp).container
                AuthViewModel(appContainer.authRepository)
            }
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentLoginBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.emailInput.doAfterTextChanged { viewModel.clearError() }
        binding.passwordInput.doAfterTextChanged { viewModel.clearError() }

        binding.loginButton.setOnClickListener {
            viewModel.login(
                binding.emailInput.text?.toString().orEmpty(),
                binding.passwordInput.text?.toString().orEmpty()
            )
        }
        binding.registerButton.setOnClickListener {
            findNavController().navigate(R.id.action_login_to_register)
        }

        viewLifecycleOwner.lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.uiState.collect { state ->
                    binding.loginButton.isEnabled = !state.isLoading
                    binding.loginProgress.visibility = if (state.isLoading) View.VISIBLE else View.GONE
                    binding.loginButton.text = if (state.isLoading) "" else "Log in"

                    if (state.errorMessage != null) {
                        binding.errorText.text = state.errorMessage
                        binding.errorText.visibility = View.VISIBLE
                    } else {
                        binding.errorText.visibility = View.GONE
                    }

                    if (state.isAuthenticated) {
                        findNavController().navigate(R.id.action_login_to_home)
                    }
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

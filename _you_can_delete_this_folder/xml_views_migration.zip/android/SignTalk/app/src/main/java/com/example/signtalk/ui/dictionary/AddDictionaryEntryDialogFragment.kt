package com.example.signtalk.ui.dictionary

import android.app.Dialog
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.lifecycleScope
import com.example.signtalk.SignTalkApp
import com.example.signtalk.databinding.DialogAddDictionaryEntryBinding
import com.example.signtalk.domain.model.DictionaryEntry
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch

/**
 * Plain-Views replacement for the old Compose `AddDictionaryEntryDialog`.
 * Talks straight to [com.example.signtalk.domain.repository.DictionaryRepository]
 * rather than sharing a ViewModel with the host fragment -- the host's list
 * is a Room [kotlinx.coroutines.flow.Flow] and refreshes on its own the
 * moment a new row is inserted, so no explicit callback is needed here.
 */
class AddDictionaryEntryDialogFragment : DialogFragment() {

    private var _binding: DialogAddDictionaryEntryBinding? = null
    private val binding get() = _binding!!

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogAddDictionaryEntryBinding.inflate(layoutInflater)

        val dialog = MaterialAlertDialogBuilder(requireContext())
            .setTitle("Add a sign")
            .setView(binding.root)
            .setPositiveButton("Add", null) // wired manually in onStart so a blank name doesn't dismiss the dialog
            .setNegativeButton("Cancel") { _, _ -> dismiss() }
            .create()

        dialog.setOnShowListener {
            (dialog as AlertDialog).getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = binding.nameInput.text?.toString()?.trim().orEmpty()
                if (name.isBlank()) {
                    binding.nameInput.error = "Required"
                    return@setOnClickListener
                }
                addEntry(name)
            }
        }
        return dialog
    }

    private fun addEntry(name: String) {
        val appContainer = (requireActivity().application as SignTalkApp).container
        val category = binding.categoryInput.text?.toString()?.trim().orEmpty()
        val emoji = binding.emojiInput.text?.toString()?.trim().orEmpty()
        val description = binding.descriptionInput.text?.toString()?.trim().orEmpty()

        lifecycleScope.launch {
            appContainer.dictionaryRepository.addEntry(
                DictionaryEntry(
                    label = name.trim().lowercase().replace(Regex("\\s+"), "_"),
                    displayName = name,
                    category = category.ifBlank { "Custom" },
                    description = description,
                    emoji = emoji.ifBlank { "🤟" },
                    isUserAdded = true
                )
            )
            dismiss()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}

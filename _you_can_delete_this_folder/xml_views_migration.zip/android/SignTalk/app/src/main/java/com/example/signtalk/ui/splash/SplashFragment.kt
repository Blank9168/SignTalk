package com.example.signtalk.ui.splash

import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.navigation.fragment.findNavController
import com.example.signtalk.R
import com.example.signtalk.SignTalkApp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/** Brief branded splash, then routes to Home if already logged in, or Login otherwise. */
class SplashFragment : Fragment(R.layout.fragment_splash) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val appContainer = (requireActivity().application as SignTalkApp).container

        viewLifecycleOwner.lifecycleScope.launch {
            delay(700)
            val session = appContainer.authRepository.currentSession.first()
            val destination = if (session != null) {
                R.id.action_splash_to_home
            } else {
                R.id.action_splash_to_login
            }
            findNavController().navigate(destination)
        }
    }
}
